package com.assignment.parts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartsApplicationTests {

	@Test
	void contextLoads() {
	}

}
